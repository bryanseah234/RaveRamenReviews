# RaveRamenReviews
A repository for a ramen review api in Python

## Disclaimer:
1. NONE

## Demo
https://rave-ramenapi.herokuapp.com

## Instructions:
1. Download the code as a zip file
2. Extract the files
3. Run the 'main.py' file to start
4. To run tests, open 'test.py' in IDLE, and uncomment the tests

## Features:
See [documentation](templates/documentation.html)
