import requests
import json

'''TESTS FOR RAVE RAMEN REVIEWS API, EDIT ACCORDINGLY'''

##url = 'http://127.0.0.1:5000/api/addone'
##data = {'hello':None,'brand':'Brand xxxx','country':'USA','ID':'2222222222222222'}
##r = requests.put(url, data=data)
##print(r.json())


##url = 'http://127.0.0.1:5000/api/addmany'
##r = requests.get(url)
##print(r.json())


##url = 'http://127.0.0.1:5000/api/editsome'
##data = {'brand':'Brand A','updatecountry':'HOLAAAA'}
##r = requests.put(url, data=data)
##print(r.json())


##url = 'http://127.0.0.1:5000/api/deletesome'
##data = {'brand':'Brand B'}
##r = requests.put(url, data=data)


##url = 'http://127.0.0.1:5000/api/searchsome'
##data = {'brand':'Brand C','sortby':'country'}
##r = requests.put(url, data=data)
##print(r.json())


##url = 'http://127.0.0.1:5000/api/searchsome'
##data = {'keyword':'seaweed','sortby':'country'}
##r = requests.put(url, data=data)
##print(r.json())


##url = 'http://127.0.0.1:5000/api/selectall'
##r = requests.get(url)
##print(r.json())


##url = 'http://127.0.0.1:5000/api/deleteall'
##r = requests.get(url)
##print(r.json())

